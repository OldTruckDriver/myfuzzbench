# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions andsss
# limitations under the License.

# pylint: disable=missing-function-docstring
"""Tests for stat_tests.py"""

import pytest

from analysis import stat_tests


def test_a12_paper():
    """Example distribution from the paper, page 106.
    """

    x_values = [1, 2, 2, 2, 2, 2, 2, 3, 3, 3]
    y_values = [1, 1, 1, 2, 2, 2, 2, 2, 2, 3]

    result = stat_tests.a12(x_values, y_values)
    assert result == pytest.approx(0.66, 0.0001)


def test_a12_equal():
    """Example distribution with equal probabilities.
    """

    x_values = [1, 1, 1, 1, 2, 2, 3, 3, 3, 3]
    y_values = [1, 2, 2, 2, 2, 2, 2, 2, 2, 3]

    result = stat_tests.a12(x_values, y_values)
    assert result == pytest.approx(0.5, 0.0001)
