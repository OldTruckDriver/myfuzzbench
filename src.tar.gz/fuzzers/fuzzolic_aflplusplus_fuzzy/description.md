# aflplusplus + fuzzolic fuzzy solver

Simple AFL++ fuzzer instance together with fuzzolic fuzzy solver

Repository: [https://github.com/AFLplusplus/AFLplusplus/](https://github.com/AFLplusplus/AFLplusplus/)
Repository: [https://github.com/season-lab/fuzzolic](https://github.com/season-lab/fuzzolic)

[builder.Dockerfile](builder.Dockerfile)
[fuzzer.py](fuzzer.py)
[runner.Dockerfile](runner.Dockerfile)
