# honggfuzz UM (prioritize)

Run honggfuzz over mutated code with UM prioritization

NOTE: This only works with C or C++ benchmarks.

[builder.Dockerfile](builder.Dockerfile)
[fuzzer.py](fuzzer.py)
[runner.Dockerfile](runner.Dockerfile)
